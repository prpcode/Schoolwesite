<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body bgcolor="black">
    <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<style id="header">
    h1{text-align: center;
        color: white;}
</style>

<style type="text/css">
    #gallery img{
        height:320px;
        width:380px;
    }


    .column {
  float: left;
  width: 33.33%;
  padding: 5px;
  text-align: center;
  color: orange;
}

/* Clear floats after image containers */
.row::after {
  content: "";
  clear: both;
  display: table;
}
</style>


        <h1><b>Achievements</b></h1> 
        
<div class="w3-row w3-center w3-padding-16 w3-section w3-red">
      <div class="w3-quarter w3-section">
        <span class="w3-xlarge">13+</span><br>
        Teacher staff
      </div>
      <div class="w3-quarter w3-section">
        <span class="w3-xlarge">15+</span><br>
        ClassRoom
      </div>
      <div class="w3-quarter w3-section">
        <span class="w3-xlarge">500+</span><br>
        Genius Student
      </div>
      <div class="w3-quarter w3-section">
        <span class="w3-xlarge">15+</span><br>
        Transport Vehicles
      </div>
    </div>


   <div id="gallery" class="row">
  <div class="column">
    <img src="images/s23.jpg" alt="Prize at State Level" style="width:90%">
    <figcaption>Prize at State Level</figcaption>
  </div>
  <div class="column">
    <img src="images/s24.jpg" alt="Prizes at National Level" style="width:90%">
    <figcaption >Prize at National Level</figcaption>
  </div>
  <div class="column">
    <img src="images/s25.jpg" alt="Cricket Award" style="width:90%">
    <figcaption>Cricket Award</figcaption>
  </div>
  </div>


   <div id="gallery" class="row">
  <div class="column">
    <img src="images/s26.jpg" alt="Prize at State Level" style="width:90%">
    <figcaption>School prizes at national level</figcaption>
  </div>
  <div class="column">
    <img src="images/s27.jpg" alt="Prizes at National Level" style="width:90%">
    <figcaption >Prize in Olympiad</figcaption>
  </div>
  <div class="column">
    <img src="images/s28.jpg" alt="Cricket Award" style="width:90%">
    <figcaption>Sports Day Prizes</figcaption>
  </div>
  </div>
 

<p align="center"><font color="white">We have well developed faculty who are working different fields such as academic activities and sports fileds. 
</font></p>



</body>


</html>